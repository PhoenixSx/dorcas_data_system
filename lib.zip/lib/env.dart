
/// Replace with your Supabase project credentials or pass via --dart-define.
class Env {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL', defaultValue: 'https://puecajmqfseqcaeuzlli.supabase.co');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB1ZWNham1xZnNlcWNhZXV6bGxpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk0MTgwMTUsImV4cCI6MjA3NDk5NDAxNX0.Uekiptt91xnZn6nH_IbtCJL5Rj4a7nWsjQPTkR_GK40');
}
